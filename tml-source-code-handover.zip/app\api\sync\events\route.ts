import { getSessionUser } from '@/lib/auth/auth-service'
import { prisma } from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const sessionUser = await getSessionUser()
  if (!sessionUser) {
    return new Response('Unauthorized', { status: 401 })
  }

  const encoder = new TextEncoder()
  let lastChecked = new Date()

  const stream = new ReadableStream({
    async start(controller) {
      // Send initial connection packet
      controller.enqueue(encoder.encode(`event: connected\ndata: ${JSON.stringify({ status: 'ok', userId: sessionUser.id })}\n\n`))

      const interval = setInterval(async () => {
        try {
          const events = await prisma.syncEvent.findMany({
            where: {
              orgId: sessionUser.orgId,
              occurredAt: { gt: lastChecked },
            },
            orderBy: { occurredAt: 'asc' },
          })

          if (events.length > 0) {
            lastChecked = new Date()
            for (const ev of events) {
              controller.enqueue(
                encoder.encode(
                  `event: sync\ndata: ${JSON.stringify({
                    id: ev.id,
                    eventType: ev.eventType,
                    entityType: ev.entityType,
                    entityId: ev.entityId,
                    payload: JSON.parse(ev.payload || '{}'),
                    occurredAt: ev.occurredAt.toISOString(),
                  })}\n\n`
                )
              )
            }
          } else {
            // Heartbeat
            controller.enqueue(encoder.encode(`event: ping\ndata: ${Date.now()}\n\n`))
          }
        } catch {
          clearInterval(interval)
          controller.close()
        }
      }, 3000)

      req.signal.addEventListener('abort', () => {
        clearInterval(interval)
        controller.close()
      })
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
    },
  })
}

