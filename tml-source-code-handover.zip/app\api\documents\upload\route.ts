import { NextResponse } from 'next/server'
import path from 'path'
import fs from 'fs'
import crypto from 'crypto'
import { prisma } from '@/lib/prisma'
import { getSessionUser } from '@/lib/auth/auth-service'
import { PermissionService } from '@/lib/auth/permission-service'
import { DOC_TYPE_LABEL } from '@/lib/labels'
import type { DocType } from '@/lib/types'

const VAULT_DIR = path.resolve(process.cwd(), 'storage_vault')
if (!fs.existsSync(VAULT_DIR)) {
  fs.mkdirSync(VAULT_DIR, { recursive: true })
}

const ALLOWED_EXTENSIONS = ['.pdf', '.jpg', '.jpeg', '.png']
const MAX_FILE_SIZE = 25 * 1024 * 1024 // 25MB

export async function POST(req: Request) {
  const sessionUser = await getSessionUser()
  if (!sessionUser) {
    return NextResponse.json({ error: 'Chưa đăng nhập.' }, { status: 401 })
  }

  try {
    const formData = await req.formData()
    const shipmentId = formData.get('shipmentId') as string
    const docType = (formData.get('docType') as string) || 'OTHER'
    const customTypeName = (formData.get('customTypeName') as string) || ''
    const docDate = (formData.get('docDate') as string) || new Date().toISOString().slice(0, 10)
    const files = formData.getAll('files') as File[]

    if (!files || files.length === 0) {
      return NextResponse.json({ error: 'Không tìm thấy file tải lên.' }, { status: 400 })
    }

    if (!shipmentId) {
      return NextResponse.json({ error: 'Vui lòng chọn lô hàng liên kết.' }, { status: 400 })
    }

    // Check shipment
    const shipment = await prisma.shipment.findUnique({
      where: { id: shipmentId },
      include: { customer: true },
    })

    if (!shipment) {
      return NextResponse.json({ error: 'Lô hàng không tồn tại.' }, { status: 404 })
    }

    // Permission check
    const perm = await PermissionService.check(sessionUser, 'DOCUMENTS', 'UPLOAD', {
      departmentId: shipment.departmentId,
      ownerId: shipment.ownerId,
    })

    if (!perm.allowed) {
      return NextResponse.json({ error: perm.reason || 'Bạn không có quyền tải chứng từ lên lô hàng này.' }, { status: 403 })
    }

    const createdDocs = []

    for (const file of files) {
      const ext = path.extname(file.name).toLowerCase()
      if (!ALLOWED_EXTENSIONS.includes(ext)) {
        return NextResponse.json(
          { error: `Định dạng ${ext} không được hỗ trợ. Chỉ chấp nhận PDF, JPG, PNG.` },
          { status: 400 }
        )
      }

      if (file.size > MAX_FILE_SIZE) {
        return NextResponse.json(
          { error: `Tập tin ${file.name} vượt quá dung lượng tối đa cho phép (25MB).` },
          { status: 400 }
        )
      }

      const fileBuffer = Buffer.from(await file.arrayBuffer())
      const checksum = crypto.createHash('sha256').update(fileBuffer).digest('hex')

      const docId = `doc_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
      const storageKey = `vault/${docId}_${file.name}`
      const diskPath = path.join(VAULT_DIR, `${docId}_${file.name}`)

      // Write physical file to storage vault
      fs.writeFileSync(diskPath, fileBuffer)

      const displayLabel = docType === 'OTHER' && customTypeName ? customTypeName : (DOC_TYPE_LABEL[docType as DocType] ?? docType)
      const title = `${displayLabel} ${shipment.jobNo}`

      // Create Document
      const newDoc = await prisma.document.create({
        data: {
          id: docId,
          orgId: sessionUser.orgId,
          shipmentId: shipment.id,
          customerId: shipment.customerId,
          departmentId: shipment.departmentId,
          type: docType,
          customTypeName: customTypeName || null,
          title,
          fileName: file.name,
          fileSizeBytes: file.size,
          storageKey,
          pages: ext === '.pdf' ? 1 : 1, // baseline
          docDate,
          createdBy: sessionUser.id,
          updatedBy: sessionUser.id,
          editedHtml: `<p>${title}</p>`,
        },
      })

      // Create Document Version 1
      await prisma.documentVersion.create({
        data: {
          documentId: newDoc.id,
          versionNumber: 1,
          fileName: file.name,
          storageKey,
          sizeBytes: file.size,
          uploadedBy: sessionUser.id,
          changeNote: 'Tải lên ban đầu',
        },
      })

      // Register Storage Object
      await prisma.storageObject.create({
        data: {
          storageKey,
          bucket: 'tml-vault',
          mimeType: file.type || 'application/octet-stream',
          sizeBytes: file.size,
          checksumSha256: checksum,
        },
      })

      // Update Shipment Requirement status to UPLOADED
      await prisma.shipmentRequirement.updateMany({
        where: { shipmentId: shipment.id, docType: docType },
        data: { status: 'UPLOADED' },
      })

      // Audit Log
      await prisma.auditLog.create({
        data: {
          orgId: sessionUser.orgId,
          userId: sessionUser.id,
          action: 'upload',
          resourceType: 'document',
          resourceId: newDoc.id,
          status: 'SUCCESS',
          diffJson: JSON.stringify({ fileName: file.name, size: file.size, shipment: shipment.jobNo }),
        },
      })

      // Sync Event
      await prisma.syncEvent.create({
        data: {
          orgId: sessionUser.orgId,
          eventType: 'DOCUMENT_CREATED',
          entityType: 'document',
          entityId: newDoc.id,
          payload: JSON.stringify({ title, shipmentId: shipment.id }),
        },
      })

      createdDocs.push(newDoc)
    }

    return NextResponse.json({
      success: true,
      count: createdDocs.length,
      documents: createdDocs,
    })
  } catch (error: any) {
    console.error('Lỗi upload chứng từ:', error)
    return NextResponse.json({ error: error.message || 'Lỗi xử lý tải lên.' }, { status: 500 })
  }
}

