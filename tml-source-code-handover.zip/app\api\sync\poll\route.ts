import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getSessionUser } from '@/lib/auth/auth-service'

export async function GET(req: Request) {
  const sessionUser = await getSessionUser()
  if (!sessionUser) {
    return NextResponse.json({ error: 'Chưa đăng nhập' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const since = searchParams.get('since')
  const sinceDate = since ? new Date(since) : new Date(Date.now() - 60000)

  const events = await prisma.syncEvent.findMany({
    where: {
      orgId: sessionUser.orgId,
      occurredAt: { gt: sinceDate },
    },
    orderBy: { occurredAt: 'asc' },
    take: 50,
  })

  return NextResponse.json({
    timestamp: new Date().toISOString(),
    events: events.map((e) => ({
      id: e.id,
      eventType: e.eventType,
      entityType: e.entityType,
      entityId: e.entityId,
      payload: JSON.parse(e.payload || '{}'),
      occurredAt: e.occurredAt.toISOString(),
    })),
  })
}

