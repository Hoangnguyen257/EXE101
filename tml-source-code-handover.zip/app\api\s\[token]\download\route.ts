import { NextResponse } from 'next/server'
import path from 'path'
import fs from 'fs'
import { prisma } from '@/lib/prisma'

const VAULT_DIR = path.resolve(process.cwd(), 'storage_vault')

export async function GET(req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params

  const share = await prisma.documentShare.findUnique({
    where: { token },
    include: { document: { include: { ocrResults: true } } },
  })

  if (!share || share.isRevoked) {
    return NextResponse.json({ error: 'Liên kết không tồn tại hoặc đã bị thu hồi.' }, { status: 404 })
  }

  if (share.expiresAt < new Date()) {
    return NextResponse.json({ error: 'Liên kết chia sẻ đã hết hạn.' }, { status: 410 })
  }

  if (!share.allowDownload) {
    return NextResponse.json({ error: 'Tài liệu này chỉ cho phép xem trực tuyến, không được phép tải xuống.' }, { status: 403 })
  }

  const { document: doc } = share

  // Find physical file in vault
  const expectedDiskPath = path.join(VAULT_DIR, path.basename(doc.storageKey))
  const directPath = path.join(VAULT_DIR, doc.fileName)

  let fileBuffer: Buffer
  let contentType = 'application/pdf'

  if (fs.existsSync(expectedDiskPath)) {
    fileBuffer = fs.readFileSync(expectedDiskPath)
  } else if (fs.existsSync(directPath)) {
    fileBuffer = fs.readFileSync(directPath)
  } else {
    const content = doc.ocrResults[0]?.rawText || `TML DOCMANAGER: ${doc.title}\nJob: ${doc.shipmentId}`
    fileBuffer = Buffer.from(content, 'utf-8')
    contentType = 'text/plain;charset=utf-8'
  }

  // Update view/download count
  await prisma.documentShare.update({
    where: { id: share.id },
    data: { viewCount: { increment: 1 } },
  })

  const headers = new Headers()
  headers.set('Content-Type', contentType)
  headers.set('Content-Disposition', `attachment; filename="${encodeURIComponent(doc.fileName)}"`)
  headers.set('Content-Length', fileBuffer.length.toString())

  return new Response(fileBuffer, { headers })
}

