import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'

export async function POST(req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const { password } = await req.json()

  const share = await prisma.documentShare.findUnique({
    where: { token },
  })

  if (!share || share.isRevoked) {
    return NextResponse.json({ error: 'Liên kết không hợp lệ.' }, { status: 404 })
  }

  if (share.expiresAt < new Date()) {
    return NextResponse.json({ error: 'Liên kết đã hết hạn.' }, { status: 410 })
  }

  if (!share.passwordHash) {
    return NextResponse.json({ success: true })
  }

  const isValid = await bcrypt.compare(password || '', share.passwordHash)

  if (!isValid) {
    return NextResponse.json({ error: 'Mật khẩu truy cập không chính xác.' }, { status: 401 })
  }

  return NextResponse.json({ success: true })
}

