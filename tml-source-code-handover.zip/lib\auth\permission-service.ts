import { prisma } from '@/lib/prisma'
import type { AuthUser } from './auth-service'

export type PermissionAction =
  | 'VIEW'
  | 'CREATE'
  | 'EDIT'
  | 'DELETE'
  | 'UPLOAD'
  | 'DOWNLOAD'
  | 'SHARE'
  | 'APPROVE'
  | 'EXPORT'
  | 'ASSIGN'
  | 'RESTORE'
  | 'MANAGE'

export type PermissionModule =
  | 'DOCUMENTS'
  | 'SHIPMENTS'
  | 'USERS'
  | 'DEPARTMENTS'
  | 'AUDIT'
  | 'SETTINGS'
  | 'ARCHIVE'

export type ResourceScope =
  | 'GLOBAL'
  | 'ORGANIZATION'
  | 'DEPARTMENT'
  | 'ASSIGNED'
  | 'SHARED'
  | 'OWNED'

export interface ResourceContext {
  id?: string
  departmentId?: string | null
  createdBy?: string
  ownerId?: string
  assignedUserIds?: string[]
}

export interface EffectivePermission {
  code: string
  module: PermissionModule
  action: PermissionAction
  isGranted: boolean
  scope: ResourceScope
  origin: 'ROLE' | 'USER_OVERRIDE' | 'DEPARTMENT_POLICY' | 'ADMIN_BYPASS'
}

export class PermissionService {
  /**
   * Kiểm tra quyền thao tác chi tiết: RBAC + Department + Resource-Level
   */
  static async check(
    user: AuthUser | null,
    module: PermissionModule,
    action: PermissionAction,
    resource?: ResourceContext
  ): Promise<{ allowed: boolean; reason?: string }> {
    if (!user) {
      return { allowed: false, reason: 'Chưa đăng nhập (Unauthenticated).' }
    }

    if (!user.isActive) {
      return { allowed: false, reason: 'Tài khoản đã bị khóa hoặc ngừng hoạt động.' }
    }

    // ADMIN có quyền tối cao (GLOBAL bypass)
    if (user.role === 'ADMIN') {
      return { allowed: true }
    }

    const permissionCode = `${module}:${action}`

    // 1. Kiểm tra Explicit Deny ở cấp User (Quy tắc: Explicit Deny > Allow)
    const userPerm = await prisma.userPermission.findFirst({
      where: {
        userId: user.id,
        permission: { code: permissionCode },
      },
      include: { permission: true },
    })

    if (userPerm && !userPerm.isGranted) {
      return { allowed: false, reason: 'Quyền đã bị Admin từ chối rõ ràng (Explicit Deny).' }
    }

    let isGranted = false
    let applicableScope: ResourceScope = 'DEPARTMENT'

    // 2. Kiểm tra User Explicit Grant
    if (userPerm && userPerm.isGranted) {
      isGranted = true
      applicableScope = userPerm.scope as ResourceScope
    }

    // 3. Nếu chưa grant ở User, kiểm tra qua Role Permissions
    if (!isGranted) {
      const rolePerm = await prisma.rolePermission.findFirst({
        where: {
          role: { code: user.role },
          permission: { code: permissionCode },
        },
      })
      if (rolePerm) {
        isGranted = true
        applicableScope = user.role === 'MANAGER' ? 'DEPARTMENT' : 'ASSIGNED'
      }
    }

    // 4. Kiểm tra qua Department Permissions
    if (!isGranted && user.departments.length > 0) {
      const deptIds = user.departments.map((d) => d.id)
      const deptPerm = await prisma.departmentPermission.findFirst({
        where: {
          departmentId: { in: deptIds },
          permission: { code: permissionCode },
        },
      })
      if (deptPerm) {
        isGranted = true
        applicableScope = deptPerm.scope as ResourceScope
      }
    }

    if (!isGranted) {
      return { allowed: false, reason: `Không có quyền ${action} trên phân hệ ${module}.` }
    }

    // 5. Kiểm tra Resource Scope (Phạm vi dữ liệu)
    if (!resource || applicableScope === 'GLOBAL' || applicableScope === 'ORGANIZATION') {
      return { allowed: true }
    }

    return this.evaluateScope(user, applicableScope, resource, module)
  }

  /**
   * Đánh giá phạm vi tài nguyên chi tiết
   */
  private static async evaluateScope(
    user: AuthUser,
    scope: ResourceScope,
    res: ResourceContext,
    module: PermissionModule
  ): Promise<{ allowed: boolean; reason?: string }> {
    // A. OWNED: Người tạo tài nguyên
    if (res.createdBy === user.id || res.ownerId === user.id) {
      return { allowed: true }
    }

    // B. ASSIGNED: Được phân công trực tiếp
    if (res.assignedUserIds && res.assignedUserIds.includes(user.id)) {
      return { allowed: true }
    }

    // C. DEPARTMENT: Thuộc cùng phòng ban
    if (scope === 'DEPARTMENT') {
      const userDeptIds = user.departments.map((d) => d.id)
      if (res.departmentId && userDeptIds.includes(res.departmentId)) {
        return { allowed: true }
      }
    }

    // D. SHARED: Kiểm tra chia sẻ nội bộ có hiệu lực
    if (res.id && module === 'DOCUMENTS') {
      const userDeptIds = user.departments.map((d) => d.id)
      const now = new Date()

      const share = await prisma.documentAccessPermission.findFirst({
        where: {
          documentId: res.id,
          OR: [
            { targetUserId: user.id },
            { targetDeptId: { in: userDeptIds } },
          ],
          AND: [
            {
              OR: [
                { expiresAt: null },
                { expiresAt: { gt: now } },
              ],
            },
          ],
        },
      })

      if (share) {
        return { allowed: true }
      }
    }

    return {
      allowed: false,
      reason: `Tài nguyên nằm ngoài phạm vi truy cập (${scope}) của người dùng.`,
    }
  }

  /**
   * Lấy ma trận quyền hiệu lực của một người dùng
   */
  static async getEffectivePermissions(userId: string): Promise<EffectivePermission[]> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        role: {
          include: {
            rolePermissions: { include: { permission: true } },
          },
        },
        departments: {
          include: {
            department: {
              include: {
                permissions: { include: { permission: true } },
              },
            },
          },
        },
        permissions: { include: { permission: true } },
      },
    })

    if (!user) return []

    const allPermissions = await prisma.permission.findMany()
    const result: EffectivePermission[] = []

    if (user.roleCode === 'ADMIN') {
      return allPermissions.map((p) => ({
        code: p.code,
        module: p.module as PermissionModule,
        action: p.action as PermissionAction,
        isGranted: true,
        scope: 'GLOBAL',
        origin: 'ADMIN_BYPASS',
      }))
    }

    const userOverrides = new Map(user.permissions.map((up) => [up.permission.code, up]))
    const rolePerms = new Set(user.role.rolePermissions.map((rp) => rp.permission.code))
    const deptPerms = new Map<string, string>()

    for (const d of user.departments) {
      for (const dp of d.department.permissions) {
        deptPerms.set(dp.permission.code, dp.scope)
      }
    }

    for (const p of allPermissions) {
      // 1. User Override
      if (userOverrides.has(p.code)) {
        const uo = userOverrides.get(p.code)!
        result.push({
          code: p.code,
          module: p.module as PermissionModule,
          action: p.action as PermissionAction,
          isGranted: uo.isGranted,
          scope: uo.scope as ResourceScope,
          origin: 'USER_OVERRIDE',
        })
        continue
      }

      // 2. Role Permission
      if (rolePerms.has(p.code)) {
        result.push({
          code: p.code,
          module: p.module as PermissionModule,
          action: p.action as PermissionAction,
          isGranted: true,
          scope: user.roleCode === 'MANAGER' ? 'DEPARTMENT' : 'ASSIGNED',
          origin: 'ROLE',
        })
        continue
      }

      // 3. Department Permission
      if (deptPerms.has(p.code)) {
        result.push({
          code: p.code,
          module: p.module as PermissionModule,
          action: p.action as PermissionAction,
          isGranted: true,
          scope: deptPerms.get(p.code)! as ResourceScope,
          origin: 'DEPARTMENT_POLICY',
        })
        continue
      }

      // Default: Not granted
      result.push({
        code: p.code,
        module: p.module as PermissionModule,
        action: p.action as PermissionAction,
        isGranted: false,
        scope: 'DEPARTMENT',
        origin: 'ROLE',
      })
    }

    return result
  }
}

