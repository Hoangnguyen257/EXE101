import { cookies } from 'next/headers'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { signSessionToken, verifySessionToken } from './jwt'

export const SESSION_COOKIE_NAME = 'tml_session_token'

export interface AuthUser {
  id: string
  orgId: string
  email: string
  name: string
  initials: string
  role: 'ADMIN' | 'MANAGER' | 'STAFF'
  departments: { id: string; name: string; code: string; isPrimary: boolean; isManager: boolean }[]
  positions: { id: string; name: string; level: number }[]
  isActive: boolean
}

export async function login(email: string, passwordPlain: string, ipAddress = '', userAgent = '') {
  const normalizedEmail = email.toLowerCase().trim()
  const user = await prisma.user.findUnique({
    where: { email: normalizedEmail },
    include: {
      departments: { include: { department: true } },
      positions: { include: { position: true } },
    },
  })

  if (!user) {
    return { success: false, error: 'Email hoặc mật khẩu không chính xác.' }
  }

  if (!user.isActive) {
    await prisma.loginHistory.create({
      data: {
        userId: user.id,
        ipAddress,
        device: userAgent,
        status: 'LOCKED',
      },
    })
    return { success: false, error: 'Tài khoản đã bị vô hiệu hóa. Vui lòng liên hệ Admin.' }
  }

  // Check temporary lock
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const minutesLeft = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000)
    return { success: false, error: `Tài khoản tạm khóa do đăng nhập sai nhiều lần. Thử lại sau ${minutesLeft} phút.` }
  }

  const isPasswordValid = await bcrypt.compare(passwordPlain, user.passwordHash)

  if (!isPasswordValid) {
    const failedAttempts = user.failedAttempts + 1
    const shouldLock = failedAttempts >= 5
    const lockedUntil = shouldLock ? new Date(Date.now() + 15 * 60 * 1000) : null // 15 mins lock

    await prisma.user.update({
      where: { id: user.id },
      data: {
        failedAttempts: shouldLock ? 0 : failedAttempts,
        lockedUntil: lockedUntil,
      },
    })

    await prisma.loginHistory.create({
      data: {
        userId: user.id,
        ipAddress,
        device: userAgent,
        status: 'FAILED_BAD_PASSWORD',
      },
    })

    return {
      success: false,
      error: shouldLock
        ? 'Bạn đã nhập sai quá 5 lần. Tài khoản bị tạm khóa 15 phút.'
        : `Mật khẩu không chính xác. Còn lại ${5 - failedAttempts} lần thử.`,
    }
  }

  // Reset failed attempts
  await prisma.user.update({
    where: { id: user.id },
    data: { failedAttempts: 0, lockedUntil: null, lastActiveAt: new Date() },
  })

  // Create DB Session
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
  const session = await prisma.session.create({
    data: {
      userId: user.id,
      tokenHash: '',
      ipAddress,
      userAgent,
      expiresAt,
    },
  })

  const token = await signSessionToken({
    userId: user.id,
    email: user.email,
    role: user.roleCode,
    sessionId: session.id,
  })

  // Update session tokenHash
  await prisma.session.update({
    where: { id: session.id },
    data: { tokenHash: token.slice(-32) },
  })

  // Log successful login
  await prisma.loginHistory.create({
    data: {
      userId: user.id,
      ipAddress,
      device: userAgent,
      status: 'SUCCESS',
    },
  })

  // Audit log
  await prisma.auditLog.create({
    data: {
      orgId: user.orgId,
      userId: user.id,
      action: 'login',
      resourceType: 'user',
      resourceId: user.id,
      ipAddress,
      device: userAgent,
      status: 'SUCCESS',
    },
  })

  // Set cookie
  const cookieStore = await cookies()
  cookieStore.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    expires: expiresAt,
  })

  return { success: true }
}

export async function logout() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value

  if (token) {
    const payload = await verifySessionToken(token)
    if (payload?.sessionId) {
      await prisma.session.updateMany({
        where: { id: payload.sessionId },
        data: { revokedAt: new Date() },
      })
      await prisma.auditLog.create({
        data: {
          orgId: 'org_tml',
          userId: payload.userId,
          action: 'logout',
          resourceType: 'user',
          resourceId: payload.userId,
          status: 'SUCCESS',
        },
      })
    }
    cookieStore.delete(SESSION_COOKIE_NAME)
  }
}

export async function getSessionUser(): Promise<AuthUser | null> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(SESSION_COOKIE_NAME)?.value

    if (!token) return null

    const payload = await verifySessionToken(token)
    if (!payload?.userId || !payload.sessionId) return null

    // Verify session in DB
    const dbSession = await prisma.session.findUnique({
      where: { id: payload.sessionId },
      include: {
        user: {
          include: {
            departments: { include: { department: true } },
            positions: { include: { position: true } },
          },
        },
      },
    })

    if (!dbSession || dbSession.revokedAt || dbSession.expiresAt < new Date()) {
      return null
    }

    const { user } = dbSession
    if (!user || !user.isActive) return null

    return {
      id: user.id,
      orgId: user.orgId,
      email: user.email,
      name: user.name,
      initials: user.initials,
      role: user.roleCode as 'ADMIN' | 'MANAGER' | 'STAFF',
      departments: user.departments.map((d) => ({
        id: d.department.id,
        name: d.department.name,
        code: d.department.code,
        isPrimary: d.isPrimary,
        isManager: d.isManager,
      })),
      positions: user.positions.map((p) => ({
        id: p.position.id,
        name: p.position.name,
        level: p.position.level,
      })),
      isActive: user.isActive,
    }
  } catch (error: any) {
    if (error?.digest === 'DYNAMIC_SERVER_USAGE' || error?.message?.includes('DYNAMIC_SERVER_USAGE')) {
      throw error
    }
    console.error('Lỗi getSessionUser:', error)
    return null
  }
}
