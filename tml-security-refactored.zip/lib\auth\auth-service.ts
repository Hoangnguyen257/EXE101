import { cookies } from 'next/headers'
import bcrypt from 'bcryptjs'
import crypto from 'crypto'
import { prisma } from '@/lib/prisma'
import { signSessionToken, verifySessionToken } from './jwt'

export const SESSION_COOKIE_NAME = 'tml_session_token'

export interface AuthUser {
  id: string
  sessionId?: string
  orgId: string
  email: string
  name: string
  initials: string
  role: 'ADMIN' | 'MANAGER' | 'STAFF'
  departments: { id: string; name: string; code: string; isPrimary: boolean; isManager: boolean }[]
  positions: { id: string; name: string; level: number }[]
  isActive: boolean
}

/**
 * Tính mã băm SHA-256 của token để lưu trữ an toàn trong DB
 */
function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex')
}

export async function login(email: string, passwordPlain: string, ipAddress = '', userAgent = '') {
  const normalizedEmail = email.toLowerCase().trim()
  const user = await prisma.user.findUnique({
    where: { email: normalizedEmail },
    include: {
      departments: { include: { department: true } },
      positions: { include: { position: true } },
    },
  })

  // Tránh tiết lộ thông tin sự tồn tại của tài khoản (Generic Error)
  if (!user) {
    return { success: false, error: 'Email hoặc mật khẩu không chính xác.' }
  }

  // Kiểm tra tài khoản có bị vô hiệu hóa bởi Admin không
  if (!user.isActive) {
    await prisma.loginHistory.create({
      data: {
        userId: user.id,
        ipAddress,
        device: userAgent,
        status: 'LOCKED',
      },
    })
    return { success: false, error: 'Tài khoản đã bị vô hiệu hóa. Vui lòng liên hệ Admin.' }
  }

  // Kiểm tra tạm khóa do brute-force 5 lần
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const minutesLeft = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000)
    return {
      success: false,
      error: `Tài khoản tạm khóa do đăng nhập sai nhiều lần. Thử lại sau ${minutesLeft} phút.`,
    }
  }

  const isPasswordValid = await bcrypt.compare(passwordPlain, user.passwordHash)

  if (!isPasswordValid) {
    const failedAttempts = user.failedAttempts + 1
    const shouldLock = failedAttempts >= 5
    const lockedUntil = shouldLock ? new Date(Date.now() + 15 * 60 * 1000) : null // Khóa 15 phút

    await prisma.user.update({
      where: { id: user.id },
      data: {
        failedAttempts: shouldLock ? 0 : failedAttempts,
        lockedUntil: lockedUntil,
      },
    })

    await prisma.loginHistory.create({
      data: {
        userId: user.id,
        ipAddress,
        device: userAgent,
        status: 'FAILED_BAD_PASSWORD',
      },
    })

    return {
      success: false,
      error: shouldLock
        ? 'Bạn đã nhập sai quá 5 lần. Tài khoản bị tạm khóa 15 phút.'
        : `Email hoặc mật khẩu không chính xác.`,
    }
  }

  // Đăng nhập thành công -> Reset số lần thất bại & mở khóa
  await prisma.user.update({
    where: { id: user.id },
    data: { failedAttempts: 0, lockedUntil: null, lastActiveAt: new Date() },
  })

  // Khởi tạo Session trong Database
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 ngày
  const session = await prisma.session.create({
    data: {
      userId: user.id,
      tokenHash: 'pending',
      ipAddress,
      userAgent,
      expiresAt,
    },
  })

  // Ký số JWT an toàn với sessionId và claims
  const token = await signSessionToken({
    userId: user.id,
    email: user.email,
    role: user.roleCode,
    sessionId: session.id,
  })

  // Lưu trữ mã băm SHA-256 của token vào database
  const tokenHash = hashToken(token)
  await prisma.session.update({
    where: { id: session.id },
    data: { tokenHash },
  })

  // Ghi nhật ký đăng nhập và Audit Log
  await prisma.loginHistory.create({
    data: {
      userId: user.id,
      ipAddress,
      device: userAgent,
      status: 'SUCCESS',
    },
  })

  await prisma.auditLog.create({
    data: {
      orgId: user.orgId,
      userId: user.id,
      action: 'login',
      resourceType: 'user',
      resourceId: user.id,
      ipAddress,
      device: userAgent,
      status: 'SUCCESS',
    },
  })

  // Thiết lập HttpOnly Cookie an toàn (khi chạy trong HTTP request context)
  try {
    const cookieStore = await cookies()
    cookieStore.set(SESSION_COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      expires: expiresAt,
    })
  } catch {
    // Cho phép chạy trong môi trường CLI hoặc automated tests
  }

  return { success: true, token }
}

export async function logout() {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(SESSION_COOKIE_NAME)?.value

    if (token) {
      const payload = await verifySessionToken(token)
      if (payload?.sessionId) {
        const session = await prisma.session.findUnique({
          where: { id: payload.sessionId },
          include: { user: true },
        })

        if (session) {
          await prisma.session.update({
            where: { id: session.id },
            data: { revokedAt: new Date() },
          })

          // Ghi Audit Log với đúng orgId của người dùng thay vì hardcode
          await prisma.auditLog.create({
            data: {
              orgId: session.user.orgId,
              userId: session.userId,
              action: 'logout',
              resourceType: 'user',
              resourceId: session.userId,
              status: 'SUCCESS',
            },
          })
        }
      }
      cookieStore.delete(SESSION_COOKIE_NAME)
    }
  } catch {
    // Cho phép chạy trong môi trường ngoài request context
  }
}

/**
 * Thu hồi toàn bộ các phiên đăng nhập đang hoạt động của người dùng (khi đổi mật khẩu hoặc khóa tài khoản)
 */
export async function revokeUserSessions(userId: string) {
  await prisma.session.updateMany({
    where: {
      userId,
      revokedAt: null,
    },
    data: {
      revokedAt: new Date(),
    },
  })
}

export async function getSessionUser(): Promise<AuthUser | null> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(SESSION_COOKIE_NAME)?.value

    if (!token) return null

    const payload = await verifySessionToken(token)
    if (!payload?.userId || !payload.sessionId) return null

    // Đối chiếu sessionId và tokenHash trong Database
    const expectedHash = hashToken(token)
    const dbSession = await prisma.session.findUnique({
      where: { id: payload.sessionId },
      include: {
        user: {
          include: {
            departments: { include: { department: true } },
            positions: { include: { position: true } },
          },
        },
      },
    })

    // Kiểm tra tính hợp lệ của phiên:
    // 1. Phải tồn tại trong database
    // 2. TokenHash phải trùng khớp
    // 3. Chưa bị thu hồi (revokedAt is null)
    // 4. Chưa hết hạn
    if (
      !dbSession ||
      dbSession.tokenHash !== expectedHash ||
      dbSession.revokedAt !== null ||
      dbSession.expiresAt < new Date()
    ) {
      return null
    }

    const { user } = dbSession

    // 5. Tài khoản phải còn hoạt động và không bị khóa
    if (!user || !user.isActive) {
      return null
    }

    if (user.lockedUntil && user.lockedUntil > new Date()) {
      return null
    }

    return {
      id: user.id,
      sessionId: dbSession.id,
      orgId: user.orgId,
      email: user.email,
      name: user.name,
      initials: user.initials,
      role: user.roleCode as 'ADMIN' | 'MANAGER' | 'STAFF',
      departments: user.departments.map((d) => ({
        id: d.department.id,
        name: d.department.name,
        code: d.department.code,
        isPrimary: d.isPrimary,
        isManager: d.isManager,
      })),
      positions: user.positions.map((p) => ({
        id: p.position.id,
        name: p.position.name,
        level: p.position.level,
      })),
      isActive: user.isActive,
    }
  } catch (error: any) {
    if (error?.digest === 'DYNAMIC_SERVER_USAGE' || error?.message?.includes('DYNAMIC_SERVER_USAGE')) {
      throw error
    }
    console.error('Lỗi getSessionUser:', error)
    return null
  }
}
